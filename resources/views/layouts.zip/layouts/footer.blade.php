<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © 2024 <a href="#"></a>. Designed by <a href="https://port.3arf.net/">GPT ERP</a> All rights reserved.</span>
		</div>
	</div>
<!-- Footer closed -->
{{-- <footer class="main-footer text-center bottom">
	<strong><a href="#">Create By GPT ERP</a></strong>
  </footer>
   --}}