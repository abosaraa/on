@inject('request', 'Illuminate\Http\Request')

@if($request->segment(1) == 'pos' && ($request->segment(2) == 'create' || $request->segment(3) == 'edit' || $request->segment(2) == 'payment'))
    @php
        $pos_layout = true;
    @endphp
@else
    @php
        $pos_layout = false;
    @endphp
@endif

@php
    $whitelist = ['127.0.0.1', '::1'];
@endphp

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') - GPT ERP</title>
  

    @include('layouts.partials.css')
    @yield('css')
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Almarai:wght@400;700;800&display=swap');
        * {
            font-family: 'Almarai', sans-serif;
        }

		.card {
			margin-top: 4em!important;
		}
		.main-footer {
			margin-top: 44vh !important;

		}

        span.dtr-data {
    padding: 0px;
    display: flex;
}

.dataTables_scroll {
    display: contents !important;
}
.form-inline {
    display: inline !important;

}

a.btn.btn-default.buttons-collection.btn-sm.dropdown-toggle {
    background: #0162e8;
    color: #fff;
    border: 2px solid #2980b9;
    font-size: 14px;
    /* font-weight: bold; */
    border-radius: 5px;
    margin-bottom: 17px;
    /* text-decoration: none; */
    cursor: pointer;
    transition: background 0.3s ease-in-out, transform 0.3s ease-in-out;
    display: inline-block;
    text-align: center;
    /* line-height: 30px; */
}
a.btn.btn-default.buttons-collection.btn-sm.dropdown-toggle:hover {
    background: #004080; /* Cambio de color al pasar el ratón */
    transform: scale(1.05); /* Escala en hover */
}

/*/* Style the dropdown menu with Flexbox */
ul.dt-button-collection.dropdown-menu {
    display: flex;
    flex-direction: column; /* Stack items vertically */
    background-color: #fff; /* Background color */
    border: 1px solid #ccc; /* Border color */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Box shadow for a subtle lift */
}

/* Style each button in the dropdown */
ul.dt-button-collection.dropdown-menu li.dt-button {
    margin: 5px 0; /* Adjust margin for space between buttons */
}

/* Style the anchor (link) inside each button */
ul.dt-button-collection.dropdown-menu li.dt-button a {
    color: #333; /* Text color */
    text-decoration: none; /* Remove underline */
    padding: 8px 12px; /* Padding for each button */
    transition: background 0.3s ease-in-out; /* Smooth background transition */
}

/* Hover effect for the buttons */
ul.dt-button-collection.dropdown-menu li.dt-button a:hover {
    background-color: #f0f0f0; /* Background color on hover */
}


/* .select2-container--default .select2-selection--single {
    display: none !important;
} */
.fa-lock:before {
    content: unset !important;
}
ul.dropdown-menu.dropdown-menu-left.show {
    position: absolute;
    transform: translate3d(-65px, -9px, 0px);
    top: 0px;
    left: 0px;
    will-change: transform;
    /* Add more styles below */
    background-color: #fff; /* Example background color */
    border: 1px solid #ccc; /* Example border */
    padding: 10px; /* Example padding */
    box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2); /* Example box shadow */
    /* Add any other styles you need */
}
table.dataTable thead .sorting::after {
    font-family: 'Ionicons';
    font-size: 11px;
    position: absolute;
    line-height: 0;
    left: 10px;
    right: auto !important;
    display: none !important;
} 
table.dataTable thead .sorting_desc::after {
    font-family: 'Ionicons';
    font-size: 11px;
    position: absolute;
    line-height: 0;
    top: 50%;
    left: 10px;
    right: auto !important;
    display: none !important;
}

.hide {
    display: none !important;
}
img.product-thumbnail-small {
    width: 100px !important;
    height: 100px !important;
}

table.dataTable thead .sorting_asc::after {
    display: none !important;
}

/* .table-responsive {
    min-height: 100vh !important;
} */
table#product_table {
    min-height: 20vh !important;
}

/* 
.select2-container--default .select2-selection--multiple:before {content: ' ';display: block;position: absolute;border-color: #888 transparent transparent transparent;border-style: solid;border-width: 5px 4px 0 4px;height: 0;right: 6px;margin-left: -4px;margin-top: -2px;top: 50%;width: 0;cursor: pointer} */

/* .select2-selection__placeholder {
    display: none !important;
} */
.app-sidebar {
        overflow-y: auto; /* Enable vertical scrolling */
        max-height: 100vh; /* Set a maximum height to limit the sidebar height */
    }
    </style>
</head>

<body class="main-body app sidebar-mini">
    <script src="{{asset('assets/plugins/toastr/toastr.min.js')}}"></script>
    <script>
        if ('') {
            var msg = '';
            toastr.success(msg);
        }
        if ('') {
            var msg = '';
            toastr.error(msg);
        }
    </script> 

    @include('layouts.main-sidebar')    

    @if(in_array($_SERVER['REMOTE_ADDR'], $whitelist))
        <input type="hidden" id="__is_localhost" value="true">
    @endif

    <div class="main-content app-content">
        {{-- <div id="global-loader">
			<img src="{{URL::asset('/img/flag-lybia.jpg')}}" class="loader-img" alt="Loader" style="width:10%">
     
		</div> --}}
            
        @include('layouts.main-header')            

        <div class="container-fluid">
            @yield('page-header')
            @yield('content')

            <div id="app">
                @yield('vue')
            </div>

            <input type="hidden" id="__code" value="{{session('currency')['code']}}">
            <input type="hidden" id="__symbol" value="{{session('currency')['symbol']}}">
            <input type="hidden" id="__thousand" value="{{session('currency')['thousand_separator']}}">
            <input type="hidden" id="__decimal" value="{{session('currency')['decimal_separator']}}">
            <input type="hidden" id="__symbol_placement" value="{{session('business.currency_symbol_placement')}}">
            <input type="hidden" id="__precision" value="{{session('business.currency_precision', 2)}}">
            <input type="hidden" id="__quantity_precision" value="{{session('business.quantity_precision', 2)}}">
            
            @can('view_export_buttons')
                <input type="hidden" id="view_export_buttons">
            @endcan

            @if(isMobile())
                <input type="hidden" id="__is_mobile">
            @endif

            @if (session('status'))
                <input type="hidden" id="status_span" data-status="{{ session('status.success') }}" data-msg="{{ session('status.msg') }}">
            @endif
        </div>

        @if(config('constants.iraqi_selling_price_adjustment'))
            <input type="hidden" id="iraqi_selling_price_adjustment">
        @endif

        <section class="invoice print_section" id="receipt_section">
        </section>

        @include('layouts.footer')
        @include('layouts.partials.javascripts')

        @if(!empty($__additional_html))
            {!! $__additional_html !!}
        @endif

        <div class="modal  view_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

        @if(!empty($__additional_views) && is_array($__additional_views))
            @foreach($__additional_views as $additional_view)
                @includeIf($additional_view)
            @endforeach
        @endif

        
    </div>
</body>
</html>
