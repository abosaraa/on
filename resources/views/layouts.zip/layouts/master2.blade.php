@inject('request', 'Illuminate\Http\Request')

@if($request->segment(1) == 'pos' && ($request->segment(2) == 'create' || $request->segment(3) == 'edit'
 || $request->segment(2) == 'payment'))
    @php
        $pos_layout = true;
    @endphp
@else
    @php
        $pos_layout = false;
    @endphp
@endif

@php
    $whitelist = ['127.0.0.1', '::1'];
@endphp

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('title') - GPT ERP</title>
        

        @include('layouts.partials.css')

        @yield('css')
   
  
     <style>
      .hide {
    display: none !important;
}

     </style>

    </head>

	<body class="main-body app sidebar-mini">
		{{-- <div id="global-loader">
			<img src="{{URL::asset('assets/img/loader.svg')}}" class="loader-img" alt="Loader">
		</div>
             --}}
    <script src="{{asset('assets/plugins/toastr/toastr.min.js')}}"></script>
    
    <script>
        if( '' ){
            var msg = '';
            toastr.success(msg);
        }
        if( '' ){
            var msg = '';
            toastr.error(msg);
        }
    </script> 
     {{--        @if(!$pos_layout)
                @include('layouts.partials.header')
                @include('layouts.partials.sidebar')
            @else
                @include('layouts.partials.header-pos')
            @endif
            <style>
              .small-box>.small-box-footer {
                position: static;
              }
              th, td {
                padding: 2px 2px;
              }
              .datepicker td, .datepicker th {
                width: 10px !important;
                height: 10px !important;
                padding: 5px 5px !important;
              }
              .btnSort {
                font-size: 12px;
                padding: 8px;
              }
              @media (max-width: 991.98px){
                button.btn.btn-default.btn-flat.dateBtn {
                  font-size: 9px;
                  padding: 0px 4px;
                }
                input#form_date {
                  font-size: 9px;
                  padding: 0;
                }
                button.btn.btn-outline-info.btn-flat {
                  padding: 6px;
                }
                .card-title {
                  font-size: 14px;
                }
                a {
                  font-size: 12px;
                }
                .datepicker {
                  left: 90px !important;
                }
              }
              .datepicker.datepicker-dropdown.dropdown-menu.datepicker-orient-left.datepicker-orient-bottom table tr td span {
                width: 40px !important;
              }
              .datepicker td, .datepicker th {
                width: 50px !important;
              }
            </style> --}}

		@include('layouts.main-sidebar')		

            @if(in_array($_SERVER['REMOTE_ADDR'], $whitelist))
                <input type="hidden" id="__is_localhost" value="true">
            @endif

            <!-- Content Wrapper. Contains page content -->
           {{--  <div class="@if(!$pos_layout) content-wrapper @endif"> --}}
			<div class="main-content app-content">
				@include('layouts.main-header')			
				<!-- container -->
				<div class="container-fluid">
					@yield('page-header')
					@yield('content')
                <!-- empty div for vuejs -->
                <div id="app">
                    @yield('vue')
                </div>
                <!-- Add currency related field-->
                <input type="hidden" id="__code" value="{{session('currency')['code']}}">
                <input type="hidden" id="__symbol" value="{{session('currency')['symbol']}}">
                <input type="hidden" id="__thousand" value="{{session('currency')['thousand_separator']}}">
                <input type="hidden" id="__decimal" value="{{session('currency')['decimal_separator']}}">
                <input type="hidden" id="__symbol_placement" value="{{session('business.currency_symbol_placement')}}">
                <input type="hidden" id="__precision" value="{{session('business.currency_precision', 2)}}">
                <input type="hidden" id="__quantity_precision" value="{{session('business.quantity_precision', 2)}}">
                <!-- End of currency related field-->
                @can('view_export_buttons')
                    <input type="hidden" id="view_export_buttons">
                @endcan
                @if(isMobile())
                    <input type="hidden" id="__is_mobile">
                @endif
                @if (session('status'))
                    <input type="hidden" id="status_span" data-status="{{ session('status.success') }}" data-msg="{{ session('status.msg') }}">
                @endif
			

              <!--   <div class='scrolltop no-print'>
                    <div class='scroll icon'><i class="fas fa-angle-up"></i></div>
                </div> -->

                @if(config('constants.iraqi_selling_price_adjustment'))
                    <input type="hidden" id="iraqi_selling_price_adjustment">
                @endif

                <!-- This will be printed -->
                <section class="invoice print_section" id="receipt_section">
                </section>
                
            </div>
            {{-- @include('home.todays_profit_modal')
            <!-- /.content-wrapper --> --}}

         

            <audio id="success-audio">
              {{-- <source src="{{ asset('/audio/success.ogg?v=' . $asset_v) }}" type="audio/ogg"> --}}
              <source src="{{ asset('/audio/success.mp3?v=' . $asset_v) }}" type="audio/mpeg">
            </audio>
            <audio id="error-audio">
              <source src="{{ asset('/audio/error.mp3?v=' . $asset_v) }}" type="audio/mpeg">
            </audio>
            <audio id="warning-audio">
              <source src="{{ asset('/audio/warning.ogg?v=' . $asset_v) }}" type="audio/ogg">
              <source src="{{ asset('/audio/warning.mp3?v=' . $asset_v) }}" type="audio/mpeg">
            </audio>
        </div>

{{-- <!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-light">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
<!-- ./wrapper --> --}}

@include('layouts.footer')
    
        @include('layouts.partials.javascripts')

   
{{-- 
        @if(!$pos_layout)
        @include('layouts.partials.footer')
    @else
        @include('layouts.partials.footer_pos')
    @endif

 --}}
    @if(!empty($__additional_html))
{!! $__additional_html !!}
@endif


<div class="modal  view_modal" tabindex="-1" role="dialog" 
aria-labelledby="gridSystemModalLabel"></div>

@if(!empty($__additional_views) && is_array($__additional_views))
@foreach($__additional_views as $additional_view)
    @includeIf($additional_view)
@endforeach
@endif
</div>

    </body>

</html> 
